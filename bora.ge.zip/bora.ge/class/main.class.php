<?php
class TopMenu{
    public function menu(){
        global $sql;
        $query = $sql->query("select * from menu order by sort asc");
        if($query){
            return $query;
        }
        return false;
    }
    public function SubMenu($id){
        global $sql;
        $query = $sql->query("select * from submenu where menuid='".$id."' order by sort asc");
        if($query){
            return $query;
        }
        return false;
    }
}
?>
