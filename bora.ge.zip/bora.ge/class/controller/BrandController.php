<?php
class Brand{

    public function index(){
        global $sql;
        $query = $sql->query("select * from brands");
        if($query){
            return $query;
        }
        return false;
    }
    public function view($c){
        global $sql;
        $query = $sql->query("select * from brands where id='".$c."'");
        if($query){
            return $query;
        }
        return false;
    }
}
$brand = new Brand();
