<?php

class Slide {
    public function index(){
        global $sql;
        $query = $sql->query("select * from slide order by sort asc");
        if($query){
            return $query;
        }
        return false;
    }
}
$slide = new Slide();
?>
