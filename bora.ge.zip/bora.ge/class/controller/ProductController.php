<?php
class Product{

    public function index($limit=0){
        global $sql;
        if($limit == NULL){
            $query = $sql->query("select * from product order by id asc");
        }else{
            $query = $sql->query("select * from product order by id asc limit 0, ".$limit);
        }
        if($query){
            return $query;
        }
        return false;
    }
    public function view($c){
        global $sql;
        $this->c=$c;
        $query = $sql->query("select * from product where brand_id='".$this->c."'");
        if($query){
            return $query;
        }
        return query;
    }
    public function edit($id){
        $this->id=$id;
        global $sql;
        $query=$sql->query("select * from news where id='".$this->id."'");
        if($query){
            return $query;
        }
        return false;
    }
    public function insert($image,$title,$text){
        global $sql;
        $query=$sql->query("insert into news (image,title,text) value ('$image','$title','$text')");
        if($query){
            return true;
        }
        return false;
    }
    public function update($image,$title,$text,$id){
        $this->id=$id;
        global $sql;
        if($image > 0){
            $res=$sql->query("select * from news where id='".$this->id."'")->fetch_array();
            $oldimage = $res['image'];
            if(unlink($oldimage)){
                $sql->query("update news set image='$image',title='$title',text='$text' where id='".$this->id."'");
            }
        }else{
            $sql->query("update news set title='$title',text='$text' where id='".$this->id."'");
        }

    }
    public function delete($id){
        $this->id=$id;
        global $sql;
        $res=$sql->query("select * from news where id='".$this->id."'")->fetch_array();
        $oldimage = $res['image'];
        if(unlink($oldimage)){
            $sql->query("delete from news where id='".$this->id."'");
        }
    }
}
$product = new Product();
?>
