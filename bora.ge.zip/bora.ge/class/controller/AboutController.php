<?php
class About{
    public function index(){
        global $sql;
        $query = $sql->query("select * from about");
        if($query){
            return $query;
        }
        return false;
    }
}
$about = new About();
