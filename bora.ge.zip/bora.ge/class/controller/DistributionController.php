<?php
class Distribution{
    public function index(){
        global $sql;
        $query = $sql->query("select * from distribution");
        if($query){
            return $query;
        }
        return false;
    }
}
$distribution = new Distribution();
