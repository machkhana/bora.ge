<?php

class Career {
    public function index(){
        global $sql;
        $query = $sql->query("select * from career");
        if($query){ return $query; } return false;
    }
    public function view($id){
        global $sql;
        $query = $sql->query("select * from career where id='". $id ."'");
        if($query){
            return $query;
        }
        return false;
    }
}
$career = new Career();