<?php
if(isset($_POST['create'])){

}
if(isset($_POST['update'])){

}
if(isset($_POST['delete'])){

}
?>
