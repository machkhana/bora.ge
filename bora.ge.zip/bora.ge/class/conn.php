<?php
ob_start();
session_start();
require_once (CONTROLLER.'/Classes.php');
$host = "localhost";
$user = "root";
$pass = "";
$db = "bora";
$sql = new mysqli($host, $user, $pass, $db);
$mycs = new Classes($sql);
$sql->query("SET NAMES utf8");
?>
