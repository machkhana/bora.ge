<?php
//$host = "";
//$user = "";
//$pass = "";
//$db = "";
//
//$sql = new mysqli($host, $user, $pass, $db);
//$sql = ('utf8');
//
//if(!$sql){return $php_errormsg;}

?>
