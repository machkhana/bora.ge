<?php if( $p =='home'){ ?>
    <nav class="main-menu">
        <div class="navbar-header">
            <!-- Toggle Button -->
            <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
                <span class="icon-bar"></span>
            </button>
        </div>
        <div class="navbar-collapse collapse clearfix">
            <ul class="navigation clearfix">
                <li><a href="#">მთავარი</a></li>
                <li class="dropdown"><a href="#">კომპანია</a>
                    <ul>
                        <li><a href="#">ჩვენს შესახებ</a></li>
                        <li><a href="#">ჩვენს შესახებ</a></li>
                        <li><a href="#">ჩვენს შესახებ</a></li>
                    </ul>
                </li>
                <li><a href="?p=product">პროდუქცია</a></li>
                <li><a href="#">დისტრიბუცია</a></li>
                <li><a href="#">სიახლეები</a></li>
                <li><a href="#">კარიერა</a></li>
                <li><a href="#">კონტაქტი</a></li>
            </ul>
        </div>
    </nav>
<?php }else{ ?>

<?php } ?>