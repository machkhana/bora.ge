<div class="header-upper">
    <div class="auto-container">
        <div class="clearfix">
            <div class="pull-left logo-outer">
                <div class="logo"><a href="index-2.html"><img src="images/logo.png" alt="" title=""></a></div>
            </div>
            <div class="pull-right upper-right clearfix">
                <!--Info Box-->
                <div class="upper-column info-box">
                    <div class="icon-box"><span class="flaticon-home"></span></div>
                    <ul>
                        <li><strong>ქინძმარაულის #15</strong></li>
                        <li>საქართველო, თბილისი</li>
                    </ul>
                </div>
                <!--Info Box-->
                <div class="upper-column info-box">
                    <div class="icon-box"><span class="flaticon-mail"></span></div>
                    <ul>
                        <li><strong>ელ-ფოსტა</strong></li>
                        <li><a href="#">info@bora.com.ge</a></li>
                    </ul>
                </div>
                <!--Info Box-->
                <div class="upper-column info-box">
                    <div class="icon-box"><span class="flaticon-phone"></span></div>
                    <ul>
                        <li><strong>ტელეფონი</strong></li>
                        <li>+99559999999</li>
                    </ul>
                </div>
            </div>
        </div>
    </div>
</div>