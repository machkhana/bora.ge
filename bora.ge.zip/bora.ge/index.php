<?php
require_once 'config.php';
include(MODULES.'./header.php');
include(MODULES.'./body.php');
include(MODULES.'./footer.php');
require_once (CONTROLLER.'/Classes.php');
?>
