<?php
require_once 'config.php';
if(isset($_GET["p"])){ $p = mysqli_real_escape_string($_GET["p"]); }
include('./modules/header.php');
include('./modules/body.php');
include('./modules/footer.php');
?>
