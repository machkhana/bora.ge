-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 23, 2019 at 09:15 AM
-- Server version: 10.4.8-MariaDB
-- PHP Version: 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `bora`
--

-- --------------------------------------------------------

--
-- Table structure for table `about`
--

CREATE TABLE `about` (
  `id` int(20) NOT NULL,
  `text_ge` text NOT NULL,
  `text_en` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `about`
--

INSERT INTO `about` (`id`, `text_ge`, `text_en`) VALUES
(1, 'შ.პ.ს „კომპანია ორბიტა“ სადისტრიბუციო კომპანიაა, რომელიც დაარსდა 2004 წელს. თუმცა კომპანია 1998 წლიდან მოღვაწეობდა სხვა სახელწოდებით. მცირე რესურსების მიუხედავად, კომპანიამ შეძლო წარმატების მიღწევა და დღესდღეობით ერთ-ერთი ლიდერი სადისტრიბუციო კომპანიაა თავის სფეროში საქართველოს ბაზარზე. კომპანია ახორციელებს დისტრიბუციას მთელი ქვეყნის ყველა რეგიონში.\r\n\r\n          პარტნიორთა ნდობისა და წარმატებული საქმიანობის შედეგად, „კომპპანია ორბიტა“ გახდა საქართველოში ექსკლუზიური დისტრიბუტორი ისეთ პოპულარულ ბრენდებზე, როგორიცაა: ETI, MOROZOVA, TAMEK, MALBI, MAESTRO DE OLIVA, IBERICA,GEMO, PROGAM, NATURELLA, VIVA, PATOS, MOKATE, MISHKINO, ITALFOOD, NMGK, TADIM, Агрокультура, Prosto, Русский Завтрак, Националь\r\n\r\n          დღესდღეობით კომპანიაში დასაქმებულია 150-ზე მეტი მაღალკვალიფიციური კადრი, რომლებიც დაკომპლექტებული არიან სხვადასხვა დეპარტამენტებში. ესენია: გაყიდვების დეპარტამენტი, ფინანსური დეპარტამენტი, მარკეტინგის დეპარტამენტი, კადრების დეპარტამენტი, ადმინისტრაცია, საწყობი და სხვა.\r\n\r\n          ჩვენ ვამაყობთ ამ მოკლე პერიოდში ჩვენი მიღწევებით და ერთგული პარტნიორებით.', 'შ.პ.ს „კომპანია ორბიტა“ სადისტრიბუციო კომპანიაა, რომელიც დაარსდა 2004 წელს. თუმცა კომპანია 1998 წლიდან მოღვაწეობდა სხვა სახელწოდებით. მცირე რესურსების მიუხედავად, კომპანიამ შეძლო წარმატების მიღწევა და დღესდღეობით ერთ-ერთი ლიდერი სადისტრიბუციო კომპანიაა თავის სფეროში საქართველოს ბაზარზე. კომპანია ახორციელებს დისტრიბუციას მთელი ქვეყნის ყველა რეგიონში.\r\n\r\n          პარტნიორთა ნდობისა და წარმატებული საქმიანობის შედეგად, „კომპპანია ორბიტა“ გახდა საქართველოში ექსკლუზიური დისტრიბუტორი ისეთ პოპულარულ ბრენდებზე, როგორიცაა: ETI, MOROZOVA, TAMEK, MALBI, MAESTRO DE OLIVA, IBERICA,GEMO, PROGAM, NATURELLA, VIVA, PATOS, MOKATE, MISHKINO, ITALFOOD, NMGK, TADIM, Агрокультура, Prosto, Русский Завтрак, Националь\r\n\r\n          დღესდღეობით კომპანიაში დასაქმებულია 150-ზე მეტი მაღალკვალიფიციური კადრი, რომლებიც დაკომპლექტებული არიან სხვადასხვა დეპარტამენტებში. ესენია: გაყიდვების დეპარტამენტი, ფინანსური დეპარტამენტი, მარკეტინგის დეპარტამენტი, კადრების დეპარტამენტი, ადმინისტრაცია, საწყობი და სხვა.\r\n\r\n          ჩვენ ვამაყობთ ამ მოკლე პერიოდში ჩვენი მიღწევებით და ერთგული პარტნიორებით.');

-- --------------------------------------------------------

--
-- Table structure for table `brands`
--

CREATE TABLE `brands` (
  `id` int(15) NOT NULL,
  `sort` int(10) NOT NULL,
  `title_ge` varchar(150) NOT NULL,
  `title_en` varchar(150) NOT NULL,
  `text_ge` text NOT NULL,
  `text_en` text NOT NULL,
  `image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `brands`
--

INSERT INTO `brands` (`id`, `sort`, `title_ge`, `title_en`, `text_ge`, `text_en`, `image`) VALUES
(1, 1, 'პეჩენია', 'პეჩენია', 'მშრალი, საკონდიტრო ნამცხვარი, ე.წ. \"პეჩენია\" თითქმის ყველა წლამდე ბავშვის მენიუში შედის. ჩაი და \"პეჩენია\", მაწონი და \"პეჩენია\" ძალიან ბევრმა მშობელმა წარმატებით გამოიყენა ბავშვის კვებაში. არადა, ეს არ გახლავთ ის საკვები, რომელიც ჩვილს ყოველდღიურ მენიუში უნდა ჩართოთ.\r\n\r\nმინდა ერთი შემთხვევა პირადი მაგალითიდან გავიხსენო: ერთხელაც, როცა ჩაიში გახსნილი \"პეჩენია\" ბოთლიდან გადმოვაქციე (კოვზით არ ჭამდა და ბოთლით მივეცით. თეფშზე ალბათ ვერც შევნიშნავდი ვერაფერს) და გასარეცხად შემთხვევით ცხელის ნაცვლად ცივ წყალს შევუშვირე, საწოვარაში მომენტალურად ', 'მშრალი, საკონდიტრო ნამცხვარი, ე.წ. \"პეჩენია\" თითქმის ყველა წლამდე ბავშვის მენიუში შედის. ჩაი და \"პეჩენია\", მაწონი და \"პეჩენია\" ძალიან ბევრმა მშობელმა წარმატებით გამოიყენა ბავშვის კვებაში. არადა, ეს არ გახლავთ ის საკვები, რომელიც ჩვილს ყოველდღიურ მენიუში უნდა ჩართოთ.\r\n\r\nმინდა ერთი შემთხვევა პირადი მაგალითიდან გავიხსენო: ერთხელაც, როცა ჩაიში გახსნილი \"პეჩენია\" ბოთლიდან გადმოვაქციე (კოვზით არ ჭამდა და ბოთლით მივეცით. თეფშზე ალბათ ვერც შევნიშნავდი ვერაფერს) და გასარეცხად შემთხვევით ცხელის ნაცვლად ცივ წყალს შევუშვირე, საწოვარაში მომენტალურად ', 'images/resource/brands/e063d9a77a04f14c8b12e1ef436eec42.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `career`
--

CREATE TABLE `career` (
  `id` int(20) NOT NULL,
  `title_ge` varchar(250) NOT NULL,
  `title_en` varchar(250) NOT NULL,
  `text_ge` text NOT NULL,
  `text_en` text NOT NULL,
  `startdate` date DEFAULT NULL,
  `enddate` date DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `career`
--

INSERT INTO `career` (`id`, `title_ge`, `title_en`, `text_ge`, `text_en`, `startdate`, `enddate`) VALUES
(1, 'ეძებს გამოცდილ მძღოლს', 'ეძებს გამოცდილ მძღოლს', 'ბორა ეძებს გამოცხილ მძღოლს', 'ბორა ეძებს გამოცხილ მძღოლს', NULL, NULL),
(2, 'ეძებს გამოცდილ მძღოლს', 'ეძებს გამოცდილ მძღოლს', 'ბორა ეძებს გამოცხილ მძღოლს', 'ბორა ეძებს გამოცხილ მძღოლს', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `distribution`
--

CREATE TABLE `distribution` (
  `id` int(5) NOT NULL,
  `text_ge` text NOT NULL,
  `text_en` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Table structure for table `menu`
--

CREATE TABLE `menu` (
  `id` int(10) NOT NULL,
  `dirname` varchar(50) NOT NULL,
  `title_ge` varchar(150) NOT NULL,
  `title_en` varchar(150) NOT NULL,
  `sort` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `menu`
--

INSERT INTO `menu` (`id`, `dirname`, `title_ge`, `title_en`, `sort`) VALUES
(1, 'home', 'მთავარი', 'home', 1),
(2, 'company', 'კომპანია', 'company', 2),
(3, 'brands', 'ბრენდები', 'brands', 3),
(4, 'distribution', 'დისტრიბუცია', 'distribution', 4),
(5, 'news', 'სიახლეები', 'news', 5),
(6, 'career', 'კარიერა', 'career', 6),
(7, 'contact', 'კონტაქტი', 'contact', 7);

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(20) NOT NULL,
  `image` text NOT NULL,
  `title_ge` varchar(250) NOT NULL,
  `title_en` varchar(250) NOT NULL,
  `shorttext_ge` text NOT NULL,
  `shorttext_en` text NOT NULL,
  `text_ge` text NOT NULL,
  `text_en` text NOT NULL,
  `date` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `image`, `title_ge`, `title_en`, `shorttext_ge`, `shorttext_en`, `text_ge`, `text_en`, `date`) VALUES
(2, 'images/resource/service-1.jpg', 'Floor Repair', '', 'გაცივებული გამჭვირვალე, რეზინასავით მასა წარმოიქმნა... გაჭირვებით მოვაცალე საწოვარას და დავაკვირდი. არაფერს ჰგავდა და არაფრის სუნი არ ჰქონდა. იყო წყალივით', 'გაცივებული გამჭვირვალე, რეზინასავით მასა წარმოიქმნა... გაჭირვებით მოვაცალე საწოვარას და დავაკვირდი. არაფერს ჰგავდა და არაფრის სუნი არ ჰქონდა. იყო წყალივით', 'გაცივებული გამჭვირვალე, რეზინასავით მასა წარმოიქმნა... გაჭირვებით მოვაცალე საწოვარას და დავაკვირდი. არაფერს ჰგავდა და არაფრის სუნი არ ჰქონდა. იყო წყალივით გამჭვირვალე, მაგრამ მკვრივი დრეკადი წარმონაქმნი... და ეს მხოლოდ \"სოსკაში\" ჩარჩენილი ულუფიდან დარჩა, წარმოიდგინეთ, რამხელა მასა იქნებოდა სავსე ბოთლში. ეს მასა ხომ ათასობით ჩვილის სხეულში ყოველდღიურად ხვდება. თანაც ეს არ ყოფილა თურქული, ჩინური ან გაურკვეველი წარმოების პროდუქტი. ამ ფირმის პეჩენია ყველაზე სანდოდ და ხარისხიანად ითვლება და ყველა მშობელი ცდილობს, ბავშვს სწორედ ის უყიდოს. როგორც ჩანს, ბავშვის ორგანიზმს მართლაც აქვს რაღაც ამოუხსნელი თავდაცვის უნარი, წინააღმდეგ შემთხვევაში დაუჯერებელია, ბავშვის სხეული ინელებდეს იმ საშინელ მასას. სარგებლობის მოტანაზე ხომ საუბარიც ზედმეტია.', '', '2019-11-15 00:00:00'),
(3, 'images/resource/service-2.jpg', 'Refinishing Floor', '', 'გაცივებული გამჭვირვალე, რეზინასავით მასა წარმოიქმნა', 'გაცივებული გამჭვირვალე, რეზინასავით მასა წარმოიქმნა', 'გაცივებული გამჭვირვალე, რეზინასავით მასა წარმოიქმნა... გაჭირვებით მოვაცალე საწოვარას და დავაკვირდი. არაფერს ჰგავდა და არაფრის სუნი არ ჰქონდა. იყო წყალივით გამჭვირვალე, მაგრამ მკვრივი დრეკადი წარმონაქმნი... და ეს მხოლოდ \"სოსკაში\" ჩარჩენილი ულუფიდან დარჩა, წარმოიდგინეთ, რამხელა მასა იქნებოდა სავსე ბოთლში. ეს მასა ხომ ათასობით ჩვილის სხეულში ყოველდღიურად ხვდება. თანაც ეს არ ყოფილა თურქული, ჩინური ან გაურკვეველი წარმოების პროდუქტი. ამ ფირმის პეჩენია ყველაზე სანდოდ და ხარისხიანად ითვლება და ყველა მშობელი ცდილობს, ბავშვს სწორედ ის უყიდოს. როგორც ჩანს, ბავშვის ორგანიზმს მართლაც აქვს რაღაც ამოუხსნელი თავდაცვის უნარი, წინააღმდეგ შემთხვევაში დაუჯერებელია, ბავშვის სხეული ინელებდეს იმ საშინელ მასას. სარგებლობის მოტანაზე ხომ საუბარიც ზედმეტია.', '', '2019-11-15 00:14:13');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `id` int(30) NOT NULL,
  `title_ge` varchar(200) NOT NULL,
  `title_en` varchar(200) NOT NULL,
  `image` text NOT NULL,
  `quantity` int(11) NOT NULL,
  `weight` varchar(30) NOT NULL,
  `brand_id` int(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`id`, `title_ge`, `title_en`, `image`, `quantity`, `weight`, `brand_id`) VALUES
(2, 'Happy Ninja', 'Happy Ninja', 'http://orbita.ge/timthumb/thumb.php?src=/upload/aCAerMbVU98jP3Ih8mrIXYr8yQUff4.png&w=270&h=190&zc=1&q=100', 34, '100', 1),
(3, 'Happy Ninja', 'Happy Ninja', 'http://orbita.ge/timthumb/thumb.php?src=/upload/aCAerMbVU98jP3Ih8mrIXYr8yQUff4.png&w=270&h=190&zc=1&q=100', 34, '100', 1),
(4, 'Happy Ninja', 'Happy Ninja', 'http://orbita.ge/timthumb/thumb.php?src=/upload/aCAerMbVU98jP3Ih8mrIXYr8yQUff4.png&w=270&h=190&zc=1&q=100', 34, '100', 1),
(5, 'Happy Ninja', 'Happy Ninja', 'http://orbita.ge/timthumb/thumb.php?src=/upload/aCAerMbVU98jP3Ih8mrIXYr8yQUff4.png&w=270&h=190&zc=1&q=100', 34, '100', 1),
(6, 'Happy Ninja', 'Happy Ninja', 'http://orbita.ge/timthumb/thumb.php?src=/upload/aCAerMbVU98jP3Ih8mrIXYr8yQUff4.png&w=270&h=190&zc=1&q=100', 34, '100', 1);

-- --------------------------------------------------------

--
-- Table structure for table `slide`
--

CREATE TABLE `slide` (
  `id` int(15) NOT NULL,
  `image` text NOT NULL,
  `sort` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Dumping data for table `slide`
--

INSERT INTO `slide` (`id`, `image`, `sort`) VALUES
(1, 'images/main-slider/image-1.jpg', 1),
(2, 'images/main-slider/image-2.jpg', 2),
(3, 'images/main-slider/image-3.jpg', 3);

-- --------------------------------------------------------

--
-- Table structure for table `submenu`
--

CREATE TABLE `submenu` (
  `id` int(10) NOT NULL,
  `title_ge` varchar(150) NOT NULL,
  `title_en` varchar(150) NOT NULL,
  `text_ge` text NOT NULL,
  `text_en` text NOT NULL,
  `sort` int(10) NOT NULL,
  `menuid` int(10) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `submenu`
--

INSERT INTO `submenu` (`id`, `title_ge`, `title_en`, `text_ge`, `text_en`, `sort`, `menuid`) VALUES
(1, 'პეჩენია', 'პეჩენია', '', '', 1, 3),
(2, 'ვაფლი', 'ვაფლი', '', '', 2, 3),
(3, 'ჩვენ შესახებ', 'ჩვენ შესახებ', 'ჩვენ შესახებ', 'ჩვენ შესახებ', 1, 2),
(4, 'მისია', 'მისია', 'მისია', 'მისია', 2, 2);

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(5) NOT NULL,
  `username` varchar(150) NOT NULL,
  `password` varchar(150) NOT NULL,
  `email` varchar(150) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `username`, `password`, `email`) VALUES
(1, 'admin', '21232f297a57a5a743894a0e4a801fc3', 'info@servicege.net');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `about`
--
ALTER TABLE `about`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `brands`
--
ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `career`
--
ALTER TABLE `career`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `distribution`
--
ALTER TABLE `distribution`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menu`
--
ALTER TABLE `menu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `slide`
--
ALTER TABLE `slide`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `submenu`
--
ALTER TABLE `submenu`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `about`
--
ALTER TABLE `about`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `brands`
--
ALTER TABLE `brands`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `career`
--
ALTER TABLE `career`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `distribution`
--
ALTER TABLE `distribution`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menu`
--
ALTER TABLE `menu`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(20) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `product`
--
ALTER TABLE `product`
  MODIFY `id` int(30) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `slide`
--
ALTER TABLE `slide`
  MODIFY `id` int(15) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `submenu`
--
ALTER TABLE `submenu`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(5) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
