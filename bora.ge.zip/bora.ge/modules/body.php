<?php
if(isset($p)){
    if(file_exists('./pages/'.$p.'.php')){
        include ('./pages/'.$p.'.php');
    }else{
        include ('./pages/404.php');
    }
}else{
    $p = 'home';
    if(file_exists('./pages/'.$p.'.php')){
        include ('./pages/'.$p.'.php');
    }
}
?>